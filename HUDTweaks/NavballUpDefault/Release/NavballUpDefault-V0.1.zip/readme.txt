Copy GameData folder to the KSP root directory

Apache License Version 2.0

by BrianErikson, https://github.com/BrianErikson/KSP