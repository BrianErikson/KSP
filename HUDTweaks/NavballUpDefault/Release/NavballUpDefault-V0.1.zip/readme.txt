DESCRIPTION:
	A simple mod to have the navball up by default in the Map View

INSTRUCTIONS:
	Move the GameData folder into the KSP root directory

License: Apache Version 2.0
By: BrianErikson
https://github.com/BrianErikson/KSP