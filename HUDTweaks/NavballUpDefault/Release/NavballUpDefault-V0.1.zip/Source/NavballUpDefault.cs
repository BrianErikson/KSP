﻿// LICENSE: Apache License Version 2.0
// By: BrianErikson

namespace NavballUpDefault
{
    [KSPAddon(KSPAddon.Startup.Flight, false)]
    public class NavballUpDefault : UnityEngine.MonoBehaviour
    {
        MapView mapView;
        bool showing;

        void Start()
        {
            mapView = MapView.fetch;
            showing = MapView.MapIsEnabled;
            if (showing && !mapView.MapCollapse_navBall.expanded)
            {
                mapView.maneuverModeToggle.OnPress.Invoke();
            }
        }

        void Update()
        {
            bool curShow = MapView.MapIsEnabled;

            // Just opened map view
            if (curShow != showing && showing == false && !mapView.MapCollapse_navBall.expanded)
            {
                mapView.maneuverModeToggle.OnPress.Invoke();
                showing = curShow;
            } 
            // Just closed map view
            else if (curShow != showing && showing == true)
            {
                showing = curShow;
            }
        }

        void OnDestroy()
        {
            mapView = null;
        }
    }
}
